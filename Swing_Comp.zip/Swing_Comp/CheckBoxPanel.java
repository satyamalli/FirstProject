import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CheckBoxPanel extends JPanel {

  

  public CheckBoxPanel() {

    // Set the layout for the JPanel
    setLayout(new GridLayout(2, 1));
    // Create checkbox with its state initialized to true
    JCheckBox cb1 = new JCheckBox("Choose Me", true);
        // Create checkbox with its state initialized to false
    JCheckBox cb2 = new JCheckBox("No Choose Me", false);
    
    add(cb1); 
    add(cb2); 
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("CheckBox Example");
    JPanel j = new CheckBoxPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 100);
    f.show();
  }
 

}
