import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JTreeDemo extends JPanel {

  public JTreeDemo() {
    setLayout(new BorderLayout());
    JTree tree = new JTree();  
	 add(tree, BorderLayout.CENTER);
  }
  
  public static void main(String args[])
  {
	  JFrame f = new JFrame ("JSplitPane Example");
    JPanel j = new JTreeDemo();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 150);
    f.show();
  }
 }