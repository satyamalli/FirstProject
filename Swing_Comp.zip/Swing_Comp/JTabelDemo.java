import java.awt.*;

import java.awt.event.*;

import javax.swing.*;

public class JTabelDemo extends JFrame
{
	public JTabelDemo()
	{
		Container content=getContentPane();
		
		content.setLayout(new BorderLayout());
		
		String[] ColHead={"Name","Rollno","Place"};
		
		String[][] data={{"xyz","123","rls"},{"Axyz","124","Drls"},{"Bxyz","125","Erls"}};
		
		JTable table=new JTable(data,ColHead);
		
		JScrollPane jsp=new JScrollPane(table);
		
		content.add(jsp,BorderLayout.CENTER);
		
		/*addWindowListener(new WindowAdapter() {
      
		  public void windowClosing(WindowEvent e) {
        
			  System.exit(0);
      
		  }
    
		  });
		*/
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(400,200);
		
		setVisible(true);
	}
	
	public static void main(String args[])
	{
		setDefaultLookAndFeelDecorated(true);
		
		new JTabelDemo();
	}
	
}