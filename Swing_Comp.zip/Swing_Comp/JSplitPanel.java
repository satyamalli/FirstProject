import java.awt.*;

import java.awt.event.*;

import javax.swing.*;

public class JSplitPanel extends JPanel {

  
	public JSplitPanel() 
	{
    
	  setLayout(new BorderLayout());
    	
	  JTree tree = new JTree();    
    	
	  JScrollPane left = new JScrollPane(tree);
    
	  JScrollPane right = new JScrollPane();
	
	  //left.setMinimumSize(new Dimension(0,0));
    
	  //right.setMinimumSize(new Dimension(0,0));
    
	  JSplitPane pane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, right);
	  
	  //JSplitPane pane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, left, right);
    	
	  //pane.setDividerLocation(-2);    
    
	  pane.setOneTouchExpandable(true);
    	
	  add(pane, BorderLayout.CENTER);
  
  }
  
  public static void main (String args[]) {
    
	  JFrame.setDefaultLookAndFeelDecorated(true);
	  
	  JFrame f = new JFrame ("JSplitPane Example");
    
	  JPanel j = new JSplitPanel();
    
	 /* f.addWindowListener(new WindowAdapter() {
      
		  public void windowClosing(WindowEvent e) {
        
			  System.exit(0);
      
		  }
    
		  });*/
	  
	 //f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  
    f.getContentPane().add (j, BorderLayout.CENTER);
    
	f.setSize (800, 500);
    
	f.show();
  
  }

}
