import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JColorFrame extends JFrame implements ActionListener 
{	
	JButton b1;
	JColorFrame()
	{
		Container content=getContentPane();
		b1=new JButton("SetColor");
		b1.addActionListener(this);
		content.add(b1,BorderLayout.NORTH);
		
		addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					System.exit(0);
				}
			});
		
		setSize(300,300);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==b1)
		{
			Color bgcolor=JColorChooser.showDialog(this,"Select the color",getBackground());
			if(bgcolor!=null)
				getContentPane().setBackground(bgcolor);
		}
	}
	
	public static void main(String args[])
	{
		//JHelloWorldFrame jf=new JHelloWorldFrame();
		//jf.show();
		new JColorFrame();
	}
}