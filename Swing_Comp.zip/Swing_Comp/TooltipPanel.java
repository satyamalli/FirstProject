import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class TooltipPanel extends JFrame implements ActionListener{
  
	JButton myButton;
	
	Container content;
	
	TooltipPanel() {
    
	  
		content=getContentPane();
		
		myButton = new JButton("Hello");
	  
		myButton.addActionListener(this);
    
		myButton.setToolTipText("World");
    
	    getContentPane().add(myButton,BorderLayout.NORTH);
	  
		setSize (300, 100);
    
		show();
  
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==myButton)
		{
			content.setBackground(Color.red);
		}
	}



  
  public static void main (String args[]) {
    
	  JFrame f = new TooltipPanel();
    
	  //JPanel j = new TooltipPanel();
    
	  f.addWindowListener(new WindowAdapter() {
      
		  public void windowClosing(WindowEvent e) {
        
			  System.exit(0);
      
		  }
    
		  });
    
	  //f.getContentPane().add (j, BorderLayout.CENTER);
    
	  //f.setSize (300, 100);
    
	  //f.show();
  
  }
}

