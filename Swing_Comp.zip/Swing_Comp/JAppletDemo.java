import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<applet code="JAppletDemo" width=300 height=300>
</applet>
*/

public class JAppletDemo extends JApplet
{
	JButton b1;
	
	public void init()
	{
		Container content=getContentPane();
		content.setLayout(new BorderLayout());
		b1=new JButton("Check");
		content.add(b1,BorderLayout.NORTH);
		content.add(new HelloWorld(),BorderLayout.CENTER);
	}
	
	
}
class HelloWorld extends JPanel
{
	int x1,y1;
	int x2,y2;
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawString("Hello",100,100);
		g.drawLine(x1,y1,x2,y2);
		x1=x2;
		y1=y2;
		System.out.println("Inside the paint");
	}
	
/*	HelloWorld()
	{
		x1=0;
		y1=0;
		x2=0;
		y2=0;
		
		addMouseListener(new MouseAdapter()
		{
			public void mousePressed(MouseEvent e)
			{
				x1=e.getX();
				y1=e.getY();
			}
		});
		addMouseMotionListener(new MouseMotionAdapter()
		{
			public void mouseDragged(MouseEvent e)
			{
				x2=e.getX();
				y2=e.getY();
				repaint();
			}
		});
	}*/
}