import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JFrameDemo extends JFrame
{
	JButton b1,b2,b3;
	
	JFrameDemo()
	{
		Container content=getContentPane();
		content.setLayout(new FlowLayout());
		//content.setBackground(Color.white);
		//JPanel p=new JPanel();
		//p.setLayout(new FlowLayout());
		b1=new JButton("Check");
		b2=new JButton("Check");
		b3=new JButton("Check");
		content.add(b1);
		content.add(b2);
		content.add(b3);
		//content.add(p,BorderLayout.NORTH);
		addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					System.exit(0);
				}
			});
		setSize(300,300);
		setVisible(true);
	}
	
	public static void main(String args[])
	{
		JFrameDemo jf=new JFrameDemo();
		jf.show();
	}
}