import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class FrameDemo extends Frame
{
	Button b1,b2,b3;
	
	FrameDemo()
	{
		
		Panel p=new Panel();
		p.setLayout(new FlowLayout());
		b1=new Button("Check");
		b2=new Button("Check");
		b3=new Button("Check");
		p.add(b1);
		p.add(b2);
		p.add(b3);
		add(p,BorderLayout.NORTH);
		addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					System.exit(0);
				}
			});
		setSize(300,300);
		setVisible(true);
	}
	
	public static void main(String args[])
	{
		FrameDemo jf=new FrameDemo();
		
	}
}