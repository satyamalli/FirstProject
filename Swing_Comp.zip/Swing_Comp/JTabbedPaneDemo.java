import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
/*
<applet code="JTabbedPaneDemo" width=300 height=300>
</applet>

*/

public class JTabbedPaneDemo extends JFrame
{
	public JTabbedPaneDemo()
	{
		JTabbedPane jtp=new JTabbedPane();
		jtp.addTab("Cities",new CitiesPanel());
		jtp.setMnemonicAt(0, KeyEvent.VK_1);
		jtp.addTab("Colors",new ColorsPanel());
		jtp.setMnemonicAt(1, KeyEvent.VK_2);
		jtp.addTab("Flavors",new FlavorsPanel());
		jtp.setMnemonicAt(2, KeyEvent.VK_3);
		getContentPane().add(jtp);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(300,300);
		setVisible(true);
	}
	
	class CitiesPanel extends JPanel
	{
		public CitiesPanel()
		{
			JButton b1=new JButton("New York");
			add(b1);
			JButton b2=new JButton("London");
			add(b2);
			JButton b3=new JButton("Mumbai");
			add(b3);
		}
	}
	class ColorsPanel extends JPanel
	{
		public ColorsPanel()
		{
			JButton b1=new JButton("Red");
			add(b1);
			JButton b2=new JButton("Blue");
			add(b2);
			JButton b3=new JButton("Yellow");
			add(b3);
		}
	}
	class FlavorsPanel extends JPanel
	{
		public FlavorsPanel()
		{
			JButton b1=new JButton("Vanila");
			add(b1);
			JButton b2=new JButton("Chocolate");
			add(b2);
			JButton b3=new JButton("Strawberry");
			add(b3);
		}
	}
	
	public static void main(String args[])
	{
		setDefaultLookAndFeelDecorated(true);
		JFrame jframe=new JTabbedPaneDemo();
		
		
	}
}